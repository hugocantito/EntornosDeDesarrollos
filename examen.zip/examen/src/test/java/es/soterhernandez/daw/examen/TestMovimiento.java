package es.soterhernandez.daw.examen;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TestMovimiento {

	private static Movimiento mov;
	
	@BeforeAll
	static void init(){
		mov = new Movimiento();
	}

	@AfterAll
	static void fin() {
		mov = null;
	}

}
