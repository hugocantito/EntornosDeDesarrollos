package es.soterhernandez.daw.examen;

import static org.junit.jupiter.api.Assertions.*;

import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TestCuenta extends CoreMatchers{

	private static Cuenta cuenta;
	
	@BeforeAll
	static void init() {
		cuenta = new Cuenta("5", "Pepe");
	}

	@AfterAll
	static void fin() {
		cuenta = null;
	}

	@Test
	void testIngresar() throws IngresoNegativoException {
		boolean error = false;
		cuenta.ingresar("concepto", 2);
		
		if(cuenta.mMovimientos == null)
			error = true;
		
		assertTrue(error, "ERROR METODO INGRESO");		
	}

	@Test
	void testRetirar() throws IngresoNegativoException, SaldoInsuficienteException {
		boolean error = false;
		cuenta.retirar("retirar", 20);
		
		if(cuenta.mMovimientos == null)
			error = true;
		
		assertTrue(error, "ERROR METODO RETIRAR");	
				
	}

	@Test
	void testGetSaldo() {
		boolean error = false;
		
		if(cuenta.getSaldo() > 0)
			error = true;
		
		assertTrue(error, "ERROR METODO GETSALDO");
	}

	@Test
	void testAddMovimiento() {
		
		boolean error = false;
		
		Movimiento mov = new Movimiento();
		cuenta.addMovimiento(mov);
		
		if(cuenta.mMovimientos == null)
			error = true;			
		
		assertTrue(error, "ERROR METODO GETSALDO");
	}

}
