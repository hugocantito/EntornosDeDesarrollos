package es.soterhernandez.daw.examen;

public class IngresoNegativoException extends Exception{
	public IngresoNegativoException(String message) {
		super(message);
	}
}
