package es.soterhernandez.daw.examen;

public class SaldoInsuficienteException extends Exception {
	
		public SaldoInsuficienteException(String message) {
			super(message);
		}
}
